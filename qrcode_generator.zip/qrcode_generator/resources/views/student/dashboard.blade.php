@extends('layouts.master')
@section('title','User - Dashboard Page - QR Code Generation using Laravel')
@include('layouts.uheader')
@section('main-content')
<div style="height:100vh;width:100%;background-image:url('{{asset('assets/images/bg.jpg')}}');background-repeat:no-repeat;background-size:100% 100%;">
<div class="container">
    <br>
    <br>
    <br>
    <br>
    <br>
    <h2 class="text-center text-white fw-bold" style="text-shadow:2px 2px 4px black;">Dashboard</h2>
</div>
</div>
@endsection

