@extends('layouts.master')
@section('title','Login Page - QR Code Generation using Laravel')
@include('layouts.uheader')
@section('main-content')
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card mt-5">
                <div class="card-header bg-success text-white"><h4 class="text-center">QR Code Generation</h4></div>
                <div class="card-body">
                    <form action="{{ route('user.create_qr') }}" method="post" autocomplete="off">
                        @csrf
                        <div class="mb-3">
                          <label for="text-content" class="form-label">Enter your text:</label>
                          <input type="text" class="form-control" id="text-content" placeholder="Enter your text or link" value="{{ old('text-content') }}" name="text-content">
                          <span class="text-danger">{{ $errors->first('text-content') }}</span>
                        </div>
                        <div class="d-grid">
                           <button type="submit" class="btn btn-success btn-block btn-lg">Create </button>
                        </div>
                      </form>
                </div>
            </div>
            <br>
            <br>
            <center>
                {{ $qrcode }}
            </center>
        </div>
    </div>
</div>
@endsection
