@extends('layouts.master')
@section('title','Login Page - QR Code Generation using Laravel')
@include('layouts.uheader')
@section('main-content')
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card mt-5">
                <div class="card-header bg-success text-white"><h4 class="text-center">Change Password</h4></div>
                <div class="card-body">
                    <form action="{{ route('user.update_password') }}" method="post" autocomplete="off">
                        @method('PATCH')
                        @csrf
                        <div class="mb-3">
                          <label for="password" class="form-label">New Password:</label>
                          <input type="password" class="form-control" id="password" placeholder="Enter password" value="{{ old('password') }}" name="password">
                          <span class="text-danger">{{ $errors->first('password') }}</span>
                        </div>
                        <div class="d-grid">
                           <button type="submit" class="btn btn-success btn-block btn-lg">Update Password</button>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

