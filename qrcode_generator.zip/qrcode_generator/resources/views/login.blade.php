@extends('layouts.master')
@section('title','Login Page - QR Code Generation using Laravel')
@include('layouts.header')
@section('main-content')
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card mt-5">
                <div class="card-header bg-success text-white"><h4 class="text-center">Login</h4></div>
                <div class="card-body">
                    <form action="{{ route('verify_login') }}" method="post" autocomplete="off">
                        @csrf
                        <div class="mb-3 mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="text" class="form-control" id="email" placeholder="Enter email" value="{{ old('email') }}" name="email">
                            <span class="text-danger">{{ $errors->first('email') }}</span>
                          </div>
                        <div class="mb-3">
                          <label for="password" class="form-label">Password:</label>
                          <input type="password" class="form-control" id="password" placeholder="Enter password" value="{{ old('password') }}" name="password">
                          <span class="text-danger">{{ $errors->first('password') }}</span>
                        </div>
                        <div class="d-grid">
                           <button type="submit" class="btn btn-success btn-block btn-lg">Sign in</button>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

