@extends('layouts.master')
@section('title','Register Page - QR Code Generation using Laravel')
@include('layouts.header')
@section('main-content')
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card mt-5">
                <div class="card-header bg-success text-white"><h4 class="text-center">Register</h4></div>
                <div class="card-body">
                    <form action="{{ route('user_register') }}" method="post" autocomplete="off">
                        @csrf
                        <div class="mb-3 mt-3">
                            <label for="name" class="form-label">Name:</label>
                            <input type="text" class="form-control" id="name" value="{{ old('name') }}" placeholder="Enter name" name="name">
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                          </div>
                        <div class="mb-3 mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="text" class="form-control" id="email" placeholder="Enter email" value="{{ old('email') }}" name="email">
                            <span class="text-danger">{{ $errors->first('email') }}</span>
                          </div>
                        <div class="mb-3 mt-3">
                          <label for="phone" class="form-label">Phone:</label>
                          <input type="text" class="form-control" id="phone" maxlength="10" value="{{ old('phone') }}" onkeypress="return is_number_check(event)" placeholder="Enter phone" name="phone">
                          <span class="text-danger">{{ $errors->first('phone') }}</span>
                        </div>
                        <div class="mb-3">
                          <label for="password" class="form-label">Password:</label>
                          <input type="password" class="form-control" id="password" placeholder="Enter password" value="{{ old('password') }}" name="password">
                          <span class="text-danger">{{ $errors->first('password') }}</span>
                        </div>
                        <div class="mb-3">
                            <label for="password_confirmation" class="form-label">Confirm Password:</label>
                            <input type="password" class="form-control" id="password_confirmation" placeholder="Retype password" value="{{ old('password_confirmation') }}" name="password_confirmation">
                            <span class="text-danger">{{ $errors->first('password_confirmation') }}</span>
                          </div>
                        <div class="d-grid">
                           <button type="submit" class="btn btn-success btn-block btn-lg">Sign up</button>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

