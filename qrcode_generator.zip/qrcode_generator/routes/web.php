<?php

use App\Http\Controllers\MainpageController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get("/",[MainpageController::class,"index"])->name('home');
Route::get("/register",[MainpageController::class,"register"])->name('register');
Route::post("/user_register",[MainpageController::class,"user_register"])->name('user_register');
Route::get("/login",[MainpageController::class,"login"])->name('login');
Route::post("/verify_login",[MainpageController::class,"verify_login"])->name('verify_login');

//user start

Route::middleware(['userAuth'])->group(function(){
    Route::get("/user/dashboard",[UserController::class,"index"])->name('user.dashboard');
    Route::get("/user/change_password",[UserController::class,"change_password"])->name('user.change_password');
    Route::get("/user/logout",[UserController::class,"logout"])->name('user.logout');
    Route::patch("/user/update_password",[UserController::class,"update_password"])->name('user.update_password');
    Route::get("/user/qrcode_generate",[UserController::class,"qrcode_generate"])->name('user.qrcode_generate');
    Route::post("/user/create_qr",[UserController::class,"create_qr"])->name('user.create_qr');
});
//user end
