<?php $__env->startSection('title','Login Page - QR Code Generation using Laravel'); ?>
<?php echo $__env->make('layouts.uheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('main-content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card mt-5">
                <div class="card-header bg-success text-white"><h4 class="text-center">QR Code Generation</h4></div>
                <div class="card-body">
                    <form action="<?php echo e(route('user.create_qr')); ?>" method="post" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                          <label for="text-content" class="form-label">Enter your text:</label>
                          <input type="text" class="form-control" id="text-content" placeholder="Enter your text or link" value="<?php echo e(old('text-content')); ?>" name="text-content">
                          <span class="text-danger"><?php echo e($errors->first('text-content')); ?></span>
                        </div>
                        <div class="d-grid">
                           <button type="submit" class="btn btn-success btn-block btn-lg">Create </button>
                        </div>
                      </form>
                </div>
            </div>
            <br>
            <br>
            <center>
                <?php echo e($qrcode); ?>

            </center>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\qrcode_generator\resources\views/student/qrcode_generate.blade.php ENDPATH**/ ?>