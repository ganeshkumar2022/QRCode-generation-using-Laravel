<?php $__env->startSection('title','User - Dashboard Page - QR Code Generation using Laravel'); ?>
<?php echo $__env->make('layouts.uheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('main-content'); ?>
<div style="height:100vh;width:100%;background-image:url('<?php echo e(asset('assets/images/bg.jpg')); ?>');background-repeat:no-repeat;background-size:100% 100%;">
<div class="container">
    <br>
    <br>
    <br>
    <br>
    <br>
    <h2 class="text-center text-white fw-bold" style="text-shadow:2px 2px 4px black;">Dashboard</h2>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\qrcode_generator\resources\views/student/dashboard.blade.php ENDPATH**/ ?>