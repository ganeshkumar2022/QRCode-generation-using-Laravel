<?php $__env->startSection('title','Login Page - QR Code Generation using Laravel'); ?>
<?php echo $__env->make('layouts.uheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('main-content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card mt-5">
                <div class="card-header bg-success text-white"><h4 class="text-center">Change Password</h4></div>
                <div class="card-body">
                    <form action="<?php echo e(route('user.update_password')); ?>" method="post" autocomplete="off">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                          <label for="password" class="form-label">New Password:</label>
                          <input type="password" class="form-control" id="password" placeholder="Enter password" value="<?php echo e(old('password')); ?>" name="password">
                          <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                        </div>
                        <div class="d-grid">
                           <button type="submit" class="btn btn-success btn-block btn-lg">Update Password</button>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\qrcode_generator\resources\views/student/change_password.blade.php ENDPATH**/ ?>