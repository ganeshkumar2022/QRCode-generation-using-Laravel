<?php

namespace App\Http\Controllers;

use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class UserController extends Controller
{
    public function index()
    {
        return view('student.dashboard');
    }
    public function change_password()
    {
        return view('student.change_password');
    }
    public function update_password(Request $request)
    {
        $request->validate([
            'password'=>'required|alpha_num'
        ]);

        $password=trim($request->input('password'));
        $password=password_hash($password,PASSWORD_DEFAULT);
        $uid=session('uid');

        $user=User::find($uid);
        $user->password=$password;

        try
        {
          $user->save();
          return back()->with('message','Password updated successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to update password');
        }
    }
    public function qrcode_generate()
    {
        $qrcode="";
        return view('student.qrcode_generate',compact('qrcode'));
    }
    public function create_qr(Request $request)
    {

        $request->validate([
            'text-content'=>'required'
        ],[
            'text-content.required'=>'Please enter text'
        ]);

        $text_content=trim($request->input('text-content'));
        $qrcode=QrCode::size(200)->generate($text_content);
        return view('student.qrcode_generate',compact('qrcode'));
    }
    public function logout()
    {
        session()->forget('uid');
        return redirect()->route('login');
    }
}
