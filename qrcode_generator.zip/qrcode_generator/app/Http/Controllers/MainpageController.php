<?php

namespace App\Http\Controllers;

use App\Models\User;
use Exception;
use Illuminate\Http\Request;

class MainpageController extends Controller
{
    public function index()
    {
        return view('home');
    }
    public function register()
    {
        return view('register');
    }
    public function user_register(Request $request)
    {
        $request->validate([
            'name'=>'required|max:30',
            'email'=>'required|email|unique:users,email',
            'phone'=>'required|numeric|unique:users,phone|digits:10',
            'password'=>'required|alpha_num|min:8|confirmed',
            'password_confirmation'=>'required|alpha_num'

        ],[
            'password_confirmation.required'=>'Confirm password field is required',
            'password_confirmation.confirmed'=>'Password and confirm password not match'
        ]);

        $name=$request->input('name');
        $email=$request->input('email');
        $phone=$request->input('phone');
        $password=password_hash($request->input('password'),PASSWORD_DEFAULT);
        try
        {
          $user=User::create(['name'=>$name,'email'=>$email,'password'=>$password,"phone"=>$phone]);
          return back()->with('message','Registered successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to register');
        }
    }
    public function login()
    {
        return view('login');
    }
    public function verify_login(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|alpha_num',

        ]);

        $email=trim($request->input('email'));
        $password=trim($request->input('password'));

        $user=User::where('email',$email)->first();
        if($user)
        {
            if(password_verify($password,$user->password))
            {
                session(['uid'=>$user->id]);
                return redirect()->route('user.dashboard');
            }
            else
            {
                return back()->with('message','Email or password incorrect');
            }
        }
        else
        {
            return back()->with('message','Email or password incorrect');
        }
    }
}
